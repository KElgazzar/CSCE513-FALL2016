import socket
import pickle
from threading import Thread 
TCP_IP = 'localhost' 
TCP_PORT = 5024
BUFFER_SIZE = 2000# Usually 1024, but we need quick response 
 




class ClientThread(Thread): 
 
    def __init__(self,ip,port): 
        Thread.__init__(self) 
        self.ip = ip 
        self.port = port 
        print "[+] New user connected " + ip + ":" + str(port) 
 
    def run(self): 
        while True : 
		received=conn.recv(2048)
		print'received',  received
		List = pickle.loads(received)
		if List in open ("token.txt").read():
			MESSGAE='TOKEN VERIFIED'
			print MESSGAE
			ER=pickle.dumps(MESSGAE)
			conn.send(ER)
			break

		
		else:
			MESGAE='TOKEN not VERIFIED'
			print MESGAE
			E=pickle.dumps(MESGAE)
			conn.send(E)
			break

tcpServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpServer.bind((TCP_IP, TCP_PORT)) 
threads = [] 
while True: 
    tcpServer.listen(4) 
    print "Cloud for verification clients..." 
    (conn, (ip,port)) = tcpServer.accept() 
    newthread = ClientThread(ip,port) 
    newthread.start() 
    threads.append(newthread) 
	
for t in threads: 
    t.join() 
