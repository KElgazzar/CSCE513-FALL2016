import socket 
from threading import Thread 
from SocketServer import ThreadingMixIn
from Crypto.Cipher import DES3
from Crypto.Cipher import AES
from Crypto import Random
import base64
import random
import pickle
import os
import ast
import threading

PUBAM="7656849403003030"
BS = 16
pad = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS) 
unpad = lambda s : s[:-ord(s[len(s)-1:])]


list_of_v=[0.0123457]
print  list_of_v
p= 23
q=11
t= 4
alpha =7
beta= alpha**((p-1)/q)%p
print ("p=%d, q=%d , t=%d, alpha=%d, beta=%d") %(p, q, t, alpha, beta)

class aes:
	def __init__( self, key ):
		self.key = key
	def encrypt( self, raw ):
		raw = pad(raw)
		iv = Random.new().read( AES.block_size )
		cipher = AES.new( self.key, AES.MODE_CBC, iv )
		return  ( iv + cipher.encrypt( raw ) )
	def decrypt( self, enc ):
		enc = (enc)
		iv = enc[:16]
		cipher = AES.new(self.key, AES.MODE_CBC, iv )
		return unpad(cipher.decrypt( enc[16:] ))

class DES3_cipher:
	def __init__(self, key):
		self.key=key
	def encrypt_DES3(self, chunk):
		des3 = DES3.new(self.key, DES3.MODE_ECB)              
  		chunk += ' ' * (16 - len(chunk) % 16)
		return (des3.encrypt(chunk))


def KSAi (BDKAM, KSN):

	h=":".join(z.encode('hex') for z in KSN)
	print "KSN", h

	BDKAM_24 =BDKAM +BDKAM[0:8]
	g=":".join (z.encode('hex') for z in BDKAM_24)
	print "bdkam", g


	cou= bytearray("FFFFFFFFFFFFFFE00000")
	ksn_bytes= bytearray(KSN)
	KSN_BITMASK=bytearray(len( ksn_bytes))
	for i in range (len(ksn_bytes)):
		KSN_BITMASK[i]=ksn_bytes[i] &cou[i]

	shift_ksn_bitmask=KSN_BITMASK[0:8]
	shift_ksn_bitmask_1=str(shift_ksn_bitmask)
	shift_ksn_bitmask_2=":".join (z.encode('hex') for z in shift_ksn_bitmask_1)
	print "shift_ksn_bitmask", shift_ksn_bitmask_2

	ipek_mask=bytearray("C0C0C0C000000000C0C0C0C000000000")
	mask=bytearray(BDKAM)
	bdkam_BITMASK=bytearray(len(mask))
	for i in range (len(mask)):
		bdkam_BITMASK[i]=mask[i] & ipek_mask[i]
	bdkam_BITMASK_1=str(bdkam_BITMASK)


	bdkam_BITMASK_24bytes=bdkam_BITMASK_1 +bdkam_BITMASK_1[0:8]
	bdkam_BITMASK_1=":".join (z.encode('hex') for z in bdkam_BITMASK_24bytes)
	print "bdkam_BITMASK_1", bdkam_BITMASK_1
	val = DES3_cipher(BDKAM_24)
	enc = str(val.encrypt_DES3 (shift_ksn_bitmask_1))
	enc_5=":".join (z.encode('hex') for z in enc)
	print "DES# out=", enc_5
	val_3 = DES3_cipher(bdkam_BITMASK_24bytes)
	enc_3 = str(val.encrypt_DES3 (KSN[0:8]))
	enc_9=":".join (z.encode('hex') for z in enc_3)
	print "DES# out=", enc_9


	return enc+enc_3
def delete_token(token_0):
	print "token_o", token_0
	o=open("token.txt", "r")
	lines= o.readlines()
	o.close()
	To_write= open ("token.txt", "w")
	for line in lines:
		if line!=token_0:
			To_write.write(line)
	To_write.close()
	print "line deleted after 13 secs'"
 

class ClientThread(Thread): 
 
	def __init__(self,ip,port): 
        	Thread.__init__(self) 
        	self.ip = ip 
        	self.port = port 
        	print "[+] New user connected " + ip + ":" + str(port) 
 
	def run(self): 
       		while True : 
			F=os.urandom(16)
			object_1=aes(PUBAM)
			enc_F=object_1.encrypt(F)
			print 'F =', F
			print 'enc_f', enc_F
			
			Fr=pickle.dumps(enc_F)
			conn.send(Fr)
			
			received=conn.recv(2048)
			print'received',  received
			enc_send_1st_list= pickle.loads(received)
			object_1=aes(PUBAM)
			dec_send_1st_list=object_1.decrypt(enc_send_1st_list)
			
			List=ast.literal_eval(dec_send_1st_list)
			xr=List[0]
			x=int (xr)
			print "x", x
			v=List[1]
			vr =str(v)
			print 'v',v
			BDKAM_234=List[2]
			print 'BDKAM_2', BDKAM_234
			jack=":".join (z.encode('hex') for z in BDKAM_234)
			print 'jack',jack
			si=List[3]

			BDKAM_si= BDKAM_234 +si
			print 'BDKAM_si',BDKAM_si
			bsai_1=KSAi (F, BDKAM_si)
			if vr in  open ('data.txt').read():
				print 'user might be there '
				e=random.randint(1, 8)
				e_r=str(e)
				object_2=aes(bsai_1)
				err=object_2.encrypt(e_r)
				er=pickle.dumps(err)
				print"e=" ,e
				conn.send(er)
			else:
				print "user not authenticated " + ip + ":" + str(port) 
				break
			si_2="\02"
			kasa_1 = bsai_1[0:9] +si_2
			bsai_2=KSAi (F, kasa_1)
			yedi = conn.recv(2048)
			print 'yedi', yedi

			y=pickle.loads(yedi)
			object_3=aes(bsai_2)
			yd=object_1.decrypt(y)
			y_1=int(yd)
			print 'y=', y_1
			z=int(float(beta**y_1*v**e%p))
			print 'z=', z
			si_3="\x03"
			Kasa_3=bsai_2[0:9]+si_3
			bsai_3=KSAi (F, Kasa_3)

			if z ==x:
				token=random.randint (100, 500)
				token_1=str (token)
				print 'token ', token
				object_4=aes(bsai_3)
				tok=object_1.encrypt(token_1)
				
				token_send = pickle.dumps(tok)
				conn.send(token_send)	
				target= open ("token.txt", "a") 
				
				target.write("\n")
				target.write(token_1)
				target.close()
				TIMER = threading.Timer(10.0,delete_token, [token_1])
				TIMER.start()
				print "timer"
				conn.send(token_send)
				break
				



			
			else: 
				message ='authenticTION FAAIL'
				conn.send(message)
				break
		

				
# Multithreaded Python server : TCP Server Socket Program Stub
TCP_IP = 'localhost' 
TCP_PORT = 5000
BUFFER_SIZE = 20  # Usually 1024, but we need quick response 
threads = []  
tcpServer = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpServer.bind((TCP_IP, TCP_PORT)) 

 
while True: 
    tcpServer.listen(4) 
    print "Multithreaded Python server : Waiting for connections from TCP clients..." 
    (conn, (ip,port)) = tcpServer.accept() 
    newthread = ClientThread(ip,port) 
    newthread.start() 
    threads.append(newthread) 
	
for t in threads: 
    t.join() 
