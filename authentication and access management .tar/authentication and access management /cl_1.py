

# Python TCP Client 
import socket 
from Crypto.Cipher import AES
from Crypto.Cipher import DES3
from Crypto import Random

import base64
import random
import pickle
BS = 16
pad = lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS) 
unpad = lambda s : s[:-ord(s[len(s)-1:])]
PUBAM="7656849403003030"

p= 23
q=11
t= 4
alpha =7
beta= alpha**((p-1)/q)%p
ID=4
h= beta**(-ID)%p
v=round(h, 7)

r = random.randint (1, (q-1))
x=(beta**r%p)

host = 'localhost' 
port = 5000
port_2= 5024
BUFFER_SIZE = 100000




print ("p=%d, q=%d , t=%d, alpha=%d, beta=%d, User_id=%d, v=%f, r=%d, x=%d") %(p, q, t, alpha, beta, ID, v, r, x)
class aes:
	def __init__( self, key ):
		self.key = key
	def encrypt( self, raw ):
		raw = pad(raw)
		iv = Random.new().read( AES.block_size )
		cipher = AES.new( self.key, AES.MODE_CBC, iv )
		return  ( iv + cipher.encrypt( raw ) )
	def decrypt( self, enc ):
		enc = (enc)
		iv = enc[:16]
		cipher = AES.new(self.key, AES.MODE_CBC, iv )
		return unpad(cipher.decrypt( enc[16:] ))
class DES3_cipher:
	def __init__(self, key):
		self.key=key
	def encrypt_DES3(self, chunk):
		des3 = DES3.new(self.key, DES3.MODE_ECB)              
  		chunk += ' ' * (16 - len(chunk) % 16)
		return (des3.encrypt(chunk))
def KSAi (BDKAM, KSN):

	h=":".join(z.encode('hex') for z in KSN)
	print "KSN", h

	BDKAM_24 =BDKAM +BDKAM[0:8]
	g=":".join (z.encode('hex') for z in BDKAM_24)
	print "bdkam", g


	cou= bytearray("FFFFFFFFFFFFFFE00000")
	ksn_bytes= bytearray(KSN)
	KSN_BITMASK=bytearray(len( ksn_bytes))
	for i in range (len(ksn_bytes)):
		KSN_BITMASK[i]=ksn_bytes[i] &cou[i]

	shift_ksn_bitmask=KSN_BITMASK[0:8]
	shift_ksn_bitmask_1=str(shift_ksn_bitmask)
	shift_ksn_bitmask_2=":".join (z.encode('hex') for z in shift_ksn_bitmask_1)
	print "shift_ksn_bitmask", shift_ksn_bitmask_2

	ipek_mask=bytearray("C0C0C0C000000000C0C0C0C000000000")
	mask=bytearray(BDKAM)
	bdkam_BITMASK=bytearray(len(mask))
	for i in range (len(mask)):
		bdkam_BITMASK[i]=mask[i] & ipek_mask[i]
	bdkam_BITMASK_1=str(bdkam_BITMASK)


	bdkam_BITMASK_24bytes=bdkam_BITMASK_1 +bdkam_BITMASK_1[0:8]
	bdkam_BITMASK_1=":".join (z.encode('hex') for z in bdkam_BITMASK_24bytes)
	print "bdkam_BITMASK_1", bdkam_BITMASK_1
	val = DES3_cipher(BDKAM_24)
	enc = str(val.encrypt_DES3 (shift_ksn_bitmask_1))
	enc_5=":".join (z.encode('hex') for z in enc)
	print "DES# out=", enc_5
	val_3 = DES3_cipher(bdkam_BITMASK_24bytes)
	enc_3 = str(val.encrypt_DES3 (KSN[0:8]))
	enc_9=":".join (z.encode('hex') for z in enc_3)
	print "DES# out=", enc_9


	return enc+enc_3


 


j=0
tcpClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
tcpClient.connect((host, port))
 
while j!=1:
	Fr=tcpClient.recv(BUFFER_SIZE)
	F=pickle.loads(Fr)
	object_1=aes(PUBAM)
	dec_F=object_1.decrypt(F)
	print 'dec_F', dec_F
	
	si='\x01'
	BDKAM_234=Random.get_random_bytes(9)
	jack=":".join (z.encode('hex') for z in BDKAM_234)
	print 'JAck', jack
	send_1st_list=[x, v, BDKAM_234, si]
	str_send_1st_list=str(send_1st_list)
	print 'send_1st_list',send_1st_list
	object_1=aes(PUBAM)
	enc_send_1st_list=object_1.encrypt(str_send_1st_list)
	rock=pickle.dumps(enc_send_1st_list)
	print 'rock',rock
	tcpClient.send(rock)
	
	
	BDKAM_si= BDKAM_234 +si
	print 'BDKAM_si',BDKAM_si
	bsai_1=KSAi (dec_F, BDKAM_si)
	
	complete = tcpClient.recv(BUFFER_SIZE)
	print 'complete', complete
	er= pickle.loads(complete)
	object_2=aes(bsai_1)
	ej=object_2.decrypt(er)
	e=int (ej)	
	print 'received e =',  e 
	si_2="\02"
	kasa_1 = bsai_1[0:9] +si_2
	bsai_2=KSAi (dec_F, kasa_1)
	yedi= str(ID*e + r%q)
	print 'yedi', yedi
	object_3=aes(bsai_2)
	yd=object_1.encrypt(yedi)
	y=pickle.dumps(yd)
	print y 
	tcpClient.send(y)

	si_3="\x03"
	Kasa_3=bsai_2[0:9]+si_3
	bsai_3=KSAi (dec_F, Kasa_3)
	token_received = tcpClient.recv(BUFFER_SIZE)
	token =pickle.loads(token_received)
	object_4=aes(bsai_3)
	tok=object_1.decrypt(token)
	tok_1=int (tok)
	
	print "token received= ", tok_1
	j=1
tcpClient.close ()
print "AAM disconnected"
tcpClient_1= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcpClient_1.connect((host, port_2))
print "connect with checker"
while True:
	tok_1=pickle.dumps(tok)
	print 'send'
	tcpClient_1.send(tok_1)
	message=tcpClient_1.recv(BUFFER_SIZE)
	mesggae_1=pickle.loads(message)
	print "message received", mesggae_1

print "error"

tcpClient_1.close()
	


    

